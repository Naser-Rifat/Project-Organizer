# Diu-project-organizer-app

<h3> It’s a web app which will organize all the project of Daffodil International University in different category which is previously done by alumni. </h3>

<h4 target="_blank"> Project Demonstration Link: https://www.youtube.com/watch?v=k1TE7IDzhjc&feature=emb_logo </h4>

![Use_case](https://user-images.githubusercontent.com/40080527/71822706-c4fca580-30bf-11ea-9b13-41e83cf634a3.png)
Fig: Use Case Diagram


![er_diagram](https://user-images.githubusercontent.com/40080527/71822885-389eb280-30c0-11ea-8fdb-26e5d1454b6f.png)
Fig: ER Diagram


![Dashboard for user](https://user-images.githubusercontent.com/40080527/71822907-48b69200-30c0-11ea-95bd-8ee6457ce96d.png)
Fig: Dashboard For User


![Department list for user](https://user-images.githubusercontent.com/40080527/71822966-6dab0500-30c0-11ea-8afe-f37a3815d702.png)
Fig: Department list for user


![Project category for user with pie chart](https://user-images.githubusercontent.com/40080527/71823016-84e9f280-30c0-11ea-89f2-4935e818bf45.png)
Fig: Project category for user with pie chart


![Category wise project list](https://user-images.githubusercontent.com/40080527/71823082-a1862a80-30c0-11ea-9e37-37eb509d5ed5.png)
Fig: Category wise project list


![All project list for user](https://user-images.githubusercontent.com/40080527/71823145-bfec2600-30c0-11ea-8d21-b833ad529bae.png)
Fig: All project list for user


![Number of project and thesis with respective supervisor](https://user-images.githubusercontent.com/40080527/71823188-dabe9a80-30c0-11ea-8202-c21da8aa4621.png)
Fig: Number of project and thesis with respective supervisor


![Question section for the user](https://user-images.githubusercontent.com/40080527/71823267-093c7580-30c1-11ea-9777-3ef2365410dd.png)
Fig: Question section for the user


![Admin login](https://user-images.githubusercontent.com/40080527/71823539-a7304000-30c1-11ea-997e-22914f4dc76a.png)
Fig: Admin login


![Form input](https://user-images.githubusercontent.com/40080527/71823603-cd55e000-30c1-11ea-83d7-bacc8863c9ff.png)
Fig:Form input


![Input form for admin](https://user-images.githubusercontent.com/40080527/71823629-e9598180-30c1-11ea-971a-ba3e1b10e01b.png)
Fig: Input form for admin


![Superadmin login form](https://user-images.githubusercontent.com/40080527/71823667-1148e500-30c2-11ea-8dcb-e241351ff50d.png)
Fig:Superadmin login form


![Superadmin control panel](https://user-images.githubusercontent.com/40080527/71823756-3b020c00-30c2-11ea-8d59-5e82496657a7.png)
Fig: Superadmin control panel


![Heidisql Login](https://user-images.githubusercontent.com/40080527/71823831-638a0600-30c2-11ea-9647-c8805db497aa.png)
Fig:Heidisql Login


![Data Storing in MySQL Database](https://user-images.githubusercontent.com/40080527/71823885-80bed480-30c2-11ea-9f82-fe72a2d52032.png)
Fig: Data Storing in MySQL Database


![User and admin’s operation](https://user-images.githubusercontent.com/40080527/71823903-8b796980-30c2-11ea-9396-fd037dfb29b3.png)
Fig: User and admin’s operation
